const mongoose = require("mongoose");

const dbURI = "mongodb+srv://suyogjadhav045:RadheRadhe7@cluster0.ochhmiv.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(dbURI).then((result) => {
    console.log("Connected to mongoDB");
})



const doctorSchema = new mongoose.Schema({
    area: {
        type: String,
        required: [true, "Please enter area"],
        minlength: [3, "Minimum length should must be 3 characters"]
    },
    specilization: {
        type: String,
        required: [true, "Please enter Specilization"],
    },
    doctorName: {
        type: String,
        required: [true, "Please enter Doctor Name"],
        minlength: [3, "Minimum length should must be 3 characters"]
    },
    docfees: {
        type: Number,
        required: [true, "Please enter Doctor Name"],
    },
    contactno: {
        type: Number,
        required: [true, "Please enter Contact Number"],
        length: [10, "length must be 10"]
    },
});

const Doctor = mongoose.model("doctor", doctorSchema);

module.exports = Doctor;