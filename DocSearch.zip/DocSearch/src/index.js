const express = require('express');
const bcrypt = require('bcrypt');
const path = require('path');
const Doctor = require('./config.js');
const app = express();


app.set('view engine', 'ejs');

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index1');
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.post("/addDoc", async (req, res) => {
    const { area, specilization, doctorName, docfees, contactno } = req.body;
    console.log(area, specilization, doctorName, docfees, contactno);
    const doctor = await Doctor.create({ area, specilization, doctorName, docfees, contactno });
    res.status(201).json({ doctor });
});

app.post('/search', async (req, res) => {
    console.log("hello");
    console.log(req.body)
    const area = req.body.input2;
    const specilization = req.body.input1;
    console.log(area, specilization);
    try {
        const data = await Doctor.find({ area: area, specilization: specilization });
        console.log(data);
        res.render('search-page', { data });
        // res.status(200).json({ data });
    } catch (err) {
        res.status(404).json({ err });
    };
});


const port = process.env.PORT || 5000;

app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
}
);